import 'package:darpik/controllers/landmark_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:get/get.dart';

class HomeView extends GetView<LandmarkController> {
  final _searchController = TextEditingController();

  final RxInt _currentIndex = 0.obs;

  HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      backgroundColor: Colors.white,
      body: Obx(() => _getPage(_currentIndex.value)),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _getPage(int index) {
    switch (index) {
      case 0:
        return _buildHomeContent();
      case 1:
        return _buildFavoritesPage();
      case 2:
        return _buildProfilePage();
      default:
        return _buildHomeContent();
    }
  }

  Widget _buildHomeContent() {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildSearchBar(),
          _buildCategories(),
          _buildFeaturedSection(),
          _buildLandmarksList(),
        ],
      ),
    );
  }

  BottomNavigationBar _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: _currentIndex.value,
      onTap: (index) => _currentIndex.value = index,
      backgroundColor: Colors.white, // لون الخلفية الأبيض
      elevation: 10.0, // زيادة ارتفاع الظل
      selectedLabelStyle: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      unselectedLabelStyle: const TextStyle(
        fontWeight: FontWeight.normal,
        fontSize: 12,
      ),
      selectedItemColor: Colors.blue,
      unselectedItemColor: Colors.grey[600],
      type: BottomNavigationBarType.fixed,
      showSelectedLabels: true,
      showUnselectedLabels: true,
      items: [
        BottomNavigationBarItem(
          icon: Container(
            padding: const EdgeInsets.all(5),
            child: const Icon(Icons.home_outlined),
          ),
          activeIcon: Container(
            padding: const EdgeInsets.all(5),
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: Colors.blue,
                  width: 2,
                ),
              ),
            ),
            child: const Icon(Icons.home),
          ),
          label: 'الرئيسية',
        ),
        BottomNavigationBarItem(
          icon: Container(
            padding: const EdgeInsets.all(5),
            child: const Icon(Icons.favorite_border),
          ),
          activeIcon: Container(
            padding: const EdgeInsets.all(5),
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: Colors.blue,
                  width: 2,
                ),
              ),
            ),
            child: const Icon(Icons.favorite),
          ),
          label: 'المفضلة',
        ),
        BottomNavigationBarItem(
          icon: Container(
            padding: const EdgeInsets.all(5),
            child: const Icon(Icons.person_outline),
          ),
          activeIcon: Container(
            padding: const EdgeInsets.all(5),
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: Colors.blue,
                  width: 2,
                ),
              ),
            ),
            child: const Icon(Icons.person),
          ),
          label: 'الملف الشخصي',
        ),
      ],
    );
  }

  // صفحات جديدة
  Widget _buildFavoritesPage() {
    return const Center(child: Text('صفحة المفضلة'));
  }

  Widget _buildProfilePage() {
    return const Center(child: Text('صفحة الملف الشخصي'));
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.white,
      title: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // أيقونة القائمة (3 خطوط)
          IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              // إضافة منطق فتح القائمة الجانبية هنا
            },
          ),
          const SizedBox(width: 12),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('دربك',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  )),
              Text('اكتشف معالم الرياض',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                  )),
            ],
          ),
        ],
      ),
      elevation: 0.1,
      shadowColor: Colors.transparent,
      surfaceTintColor: Colors.white,
      automaticallyImplyLeading: false,
      toolbarHeight: 80,
      actions: [
        IconButton(
          icon: const Icon(Icons.person, color: Colors.black),
          onPressed: () {},
        )
      ],
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(12),
        ),
        child: TextField(
          controller: _searchController,
          onSubmitted: (query) => _showSearchResults(query),
          decoration: const InputDecoration(
            hintText: 'ابحث عن معلم سياحي',
            prefixIcon: Icon(Icons.search, color: Color(0xFF006D2B)),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 16),
          ),
        ),
      ),
    );
  }

  void _showSearchResults(String query) {
    controller.filteredLandmarks.value = controller.landmarks
        .where((landmark) =>
            landmark.name.toLowerCase().contains(query.toLowerCase()))
        .toList();
    Get.to(() => MapScreen(landmarks: controller.filteredLandmarks));
  }

  Widget _buildCategories() {
    return SizedBox(
      height: 110,
      child: Obx(
        () => ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: controller.categories.keys.length,
          itemBuilder: (context, index) {
            final category = controller.categories.keys.elementAt(index);
            final icon = controller.categories.values.elementAt(index);
            return _buildCategoryItem(category, icon);
          },
        ),
      ),
    );
  }

  Widget _buildCategoryItem(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        children: [
          InkWell(
            onTap: () => controller.filterByCategory(title),
            child: Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 6,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 30, color: const Color(0xFF006D2B)),
                  const SizedBox(height: 4),
                  Text(
                    title.split(' ')[0], // يعرض الإيموجي فقط
                    style: const TextStyle(fontSize: 20),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title.substring(2), // يزيل الإيموجي من النص
            style: const TextStyle(
              fontSize: 12,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryButton(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: InkWell(
        onTap: () => controller.filterLandmarks(title),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0xFFDAA520),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  Widget _buildFeaturedSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('المعالم المميزة',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF006D2B))),
          const SizedBox(height: 8),
          _buildFeaturedCard(),
        ],
      ),
    );
  }

  Widget _buildFeaturedCard() {
    return Container(
      height: 180,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.white,
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8)],
      ),
      child: InkWell(
        onTap: () => _showLandmarkDetails(controller.filteredLandmarks.first),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: ClipRRect(
                borderRadius:
                    const BorderRadius.horizontal(left: Radius.circular(15)),
                child: Image.asset(
                  'assets/images/masmak.jpeg',
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('قصر المصمك',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text('المتحف الوطني بالرياض',
                        style: TextStyle(color: Colors.grey[600])),
                    const Spacer(),
                    const Row(
                      children: [
                        Icon(Icons.star, color: Colors.amber, size: 16),
                        Text('4.8', style: TextStyle(color: Colors.amber)),
                        Spacer(),
                        Text('ر.س150',
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF006D2B))),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLandmarksList() {
    return Obx(() {
      if (controller.filteredLandmarks.isEmpty) {
        return const Center(child: Text('لا توجد معالم متاحة'));
      }
      return ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: controller.filteredLandmarks.length,
        itemBuilder: (context, index) {
          final landmark = controller.filteredLandmarks[index];
          return _buildLandmarkItem(landmark);
        },
      );
    });
  }

  Widget _buildLandmarkItem(Landmark landmark) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: InkWell(
        onTap: () => _showLandmarkDetails(landmark),
        child: Column(
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(15)),
                  child: Image.asset(
                    landmark.imagePath,
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  top: 8,
                  left: 8,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFDAA520).withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text('\$',
                        style: const TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(landmark.name,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.location_pin, color: Color(0xFF006D2B)),
                      const SizedBox(width: 4),
                      Text(landmark.location,
                          style: TextStyle(color: Colors.grey[600])),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 16),
                      Text('${landmark.rating}',
                          style: const TextStyle(color: Colors.amber)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showLandmarkDetails(Landmark landmark) {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ), // أضف هذه القوسين للإغلاق الصحيح لـ BoxDecoration
        child: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(landmark.name,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('\$',
                      style: const TextStyle(
                          fontSize: 18,
                          color: Color(0xFF006D2B),
                          fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.location_pin, color: Color(0xFF006D2B)),
                  const SizedBox(width: 8),
                  Text(landmark.location,
                      style: TextStyle(color: Colors.grey[600])),
                ],
              ),
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  landmark.imagePath,
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 16),
              Text(landmark.description, style: const TextStyle(fontSize: 16)),
              _buildCommentsSection(
                  controller.getCommentsForLandmark(landmark.id)),
              ElevatedButton(
                onPressed: () => _showMap([landmark]),
                child: const Text('عرض الموقع على الخريطة'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF006D2B),
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCommentsSection(List<Comment> comments) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text('التعليقات',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ...comments.map((comment) => _buildCommentItem(comment)).toList(),
      ],
    );
  }

  Widget _buildCommentItem(Comment comment) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: AssetImage(controller.users
            .firstWhere((user) => user.id == comment.userId)
            .avatarPath),
      ),
      title: Text(controller.users
          .firstWhere((user) => user.id == comment.userId)
          .name),
      subtitle: Text(comment.text),
    );
  }

  void _showMap(List<Landmark> landmarks) {
    Get.to(() => MapScreen(landmarks: landmarks));
  }
}

class MapScreen extends StatelessWidget {
  final List<Landmark> landmarks;

  const MapScreen({super.key, required this.landmarks});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الموقع على الخريطة'),
      ),
      body: FlutterMap(
        options: MapOptions(
          center: landmarks.first.position,
          zoom: 14.0,
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          ),
          MarkerLayer(
            markers: landmarks
                .map((landmark) => Marker(
                      point: landmark.position,
                      child: const Icon(Icons.location_pin,
                          color: Colors.red, size: 40),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }
}
