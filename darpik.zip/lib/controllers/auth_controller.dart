

import 'package:darpik/routes/app_pages.dart';
import 'package:darpik/services/database_helper.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthController extends GetxController {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  var isLoading = false.obs;

  Future<void> register() async {
    isLoading.value = true;
    try {
      await DatabaseHelper.registerUser({
        'name': nameController.text,
        'email': emailController.text,
        'password': passwordController.text
      });
      Get.offAllNamed(Routes.HOME);
    } catch (e) {
      Get.snackbar('Error', 'Registration failed: ${e.toString()}');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> login() async {
    isLoading.value = true;
    try {
      final user = await DatabaseHelper.loginUser(
        emailController.text,
        passwordController.text,
      );
      if (user != null) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('isLoggedIn', true);
        await prefs.setString('email', emailController.text);
        emailController.clear();
        passwordController.clear();
        Get.offAllNamed(Routes.HOME);
      } else {
        Get.snackbar('خطأ', 'بيانات الاعتماد غير صحيحة',
            snackPosition: SnackPosition.BOTTOM);
      }
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('isLoggedIn');
    await prefs.remove('email');
    Get.offAllNamed(Routes.LOGIN);
  }
}