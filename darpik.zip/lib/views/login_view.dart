
import 'package:darpik/controllers/auth_controller.dart';
import 'package:darpik/routes/app_pages.dart';
import 'package:darpik/widgets/custom_textfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginView extends GetView<AuthController> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تسجيل الدخول', style: TextStyle(color: Colors.black),textAlign: TextAlign.center,),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 400),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomTextField(
                      controller: controller.emailController,
                      label: 'البريد الإلكتروني',
                      validator: (value) {
                        if (!GetUtils.isEmail(value!)) {
                          return 'البريد الإلكتروني غير صحيح';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 20),
                    CustomTextField(
                      controller: controller.passwordController,
                      label: 'كلمة المرور',
                      obscureText: true,
                      validator: (value) {
                        if (value!.length < 6) {
                          return 'يجب أن تكون كلمة المرور على الأقل 6 أحرف';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 30),
                    Obx(() => controller.isLoading.value
                        ? const CircularProgressIndicator()
                        : ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFDAA520),
                              minimumSize: const Size(double.infinity, 50),
                            ),
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                controller.login();
                              }
                            },
                            child: const Text('دخول',
                                style: TextStyle(fontSize: 18, color: Colors.black)),
                          )),
                    TextButton(
                      onPressed: () => Get.toNamed(Routes.REGISTER),
                      child: const Text('إنشاء حساب جديد',
                          style: TextStyle(color: Color(0xFF006D2B))),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}