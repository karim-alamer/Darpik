import 'package:darpik/controllers/auth_controller.dart';
import 'package:darpik/routes/app_pages.dart';
import 'package:darpik/services/database_helper.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:get/get.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp();
  SharedPreferences prefs = await SharedPreferences.getInstance();
  bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
  try {
    await DatabaseHelper.initDb();
  } catch (e) {
    print('Database initialization error: $e');
  }
  Get.lazyPut(() => AuthController());
  runApp(MyApp(isLoggedIn: isLoggedIn));
}

class MyApp extends StatelessWidget {
  final bool isLoggedIn;
  MyApp({required this.isLoggedIn});
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'دربك - الرياض',
      theme: ThemeData(
        primaryColor: const Color(0xFF006D2B),
        fontFamily: 'NotoKufiArabic',
        colorScheme: ColorScheme.fromSwatch()
            .copyWith(secondary: const Color(0xFFDAA520)),
      ),
      initialRoute: isLoggedIn ? Routes.HOME : Routes.LOGIN,
      getPages: AppPages.routes,
      locale: const Locale('ar', 'SA'),
    );
  }
}
