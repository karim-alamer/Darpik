import 'package:darpik/controllers/auth_controller.dart';
import 'package:darpik/widgets/custom_textfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class RegistrationView extends GetView<AuthController> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إنشاء حساب', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF006D2B),
      ),
      backgroundColor: Colors.white, 
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              CustomTextField(
                controller: controller.nameController,
                label: 'الاسم الكامل',
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'يرجى إدخال الاسم';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: controller.emailController,
                label: 'البريد الإلكتروني',
                validator: (value) {
                  if (!GetUtils.isEmail(value!)) {
                    return 'البريد الإلكتروني غير صحيح';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: controller.passwordController,
                label: 'كلمة المرور',
                obscureText: true,
                validator: (value) {
                  if (value!.length < 6) {
                    return 'يجب أن تكون كلمة المرور على الأقل 6 أحرف';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 30),
              Obx(() => controller.isLoading.value
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFDAA520),
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          controller.register();
                        }
                      },
                      child: const Text('تسجيل', style: TextStyle(fontSize: 18)),
                    )),
            ],
          ),
        ),
      ),
    );
  }
}