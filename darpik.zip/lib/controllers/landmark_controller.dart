import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:get/get.dart';
import 'package:latlong2/latlong.dart';

class User {
  final String id;
  final String name;
  final String avatarPath;

  User({required this.id, required this.name, required this.avatarPath});
}

class Comment {
  final String id;
  final String userId;
  final String landmarkId;
  final String text;
  final DateTime timestamp;

  Comment({
    required this.id,
    required this.userId,
    required this.landmarkId,
    required this.text,
    required this.timestamp,
  });
}

class Landmark {
  final String id;
  final String name;
  final LatLng position;
  final String imagePath;
  final String location;
  final double rating;
  final String category;
  final double price;
  final String description;

  Landmark({
    required this.id,
    required this.name,
    required this.position,
    required this.imagePath,
    required this.location,
    required this.rating,
    required this.category,
    required this.price,
    required this.description,
  });
}

class LandmarkController extends GetxController {
  final RxInt currentIndex = 0.obs;
  final categories = {
    '🏙 معالم شهيرة': Icons.landscape,
    '🎭 متاحف وأماكن ثقافية': Icons.museum,
    '🌳 حدائق ومنتزهات': Icons.park,
    '🐾 أماكن ترفيهية': Icons.attractions,
    '🛍 تسوق': Icons.shopping_cart,
    '🍽 مطاعم': Icons.restaurant,
    '🏫 جامعات': Icons.school,
    '🏥 مستشفيات': Icons.local_hospital,
    '🏛 مباني حكومية': Icons.account_balance,
    '✈ مطارات': Icons.flight,
  };

  final landmarks = <Landmark>[
    Landmark(
      id: '1',
      name: 'برج المملكة',
      position: LatLng(24.7136, 46.6753),
      imagePath: 'assets/images/kingdom_tower.jpeg',
      location: 'الرياض',
      rating: 4.8,
      category: '🏙 معالم شهيرة',
      price: 150,
      description: 'أطول برج في المملكة العربية السعودية',
    ),
    Landmark(
      id: '2',
      name: 'قصر المصمك',
      position: LatLng(24.6333, 46.7167),
      imagePath: 'assets/images/masmak.jpeg',
      location: 'الرياض',
      rating: 4.7,
      category: '🏙 معالم شهيرة',
      price: 50,
      description: 'قلعة تاريخية في قلب الرياض',
    ),

    Landmark(
      id: '3',
      name: 'المتحف الوطني السعودي',
      position: LatLng(24.6486, 46.7100),
      imagePath: 'assets/images/national_museum.jpeg',
      location: 'الرياض',
      rating: 4.9,
      category: '🎭 متاحف وأماكن ثقافية',
      price: 30,
      description: 'يعرض تاريخ المملكة العربية السعودية بطرق مبتكرة.',
    ),

    // 🌳 حدائق ومنتزهات
    Landmark(
      id: '4',
      name: 'حديقة الملك عبدالله',
      position: LatLng(24.6781, 46.6850),
      imagePath: 'assets/images/king_abdullah_park.jpeg',
      location: 'الرياض',
      rating: 4.6,
      category: '🌳 حدائق ومنتزهات',
      price: 10,
      description: 'مساحات خضراء واسعة ومناطق ترفيهية رائعة.',
    ),

    // 🐾 أماكن ترفيهية
    Landmark(
      id: '5',
      name: 'مدينة الثلج',
      position: LatLng(24.7490, 46.8572),
      imagePath: 'assets/images/snow_city.jpeg',
      location: 'الرياض',
      rating: 4.5,
      category: '🐾 أماكن ترفيهية',
      price: 100,
      description: 'تجربة تزلج ممتعة في بيئة ثلجية حقيقية.',
    ),

    // 🛍 تسوق
    Landmark(
      id: '6',
      name: 'النخيل مول',
      position: LatLng(24.7525, 46.6999),
      imagePath: 'assets/images/nakheel_mall.jpeg',
      location: 'الرياض',
      rating: 4.7,
      category: '🛍 تسوق',
      price: 0,
      description: 'أحد أكبر المولات في الرياض يضم متاجر عالمية.',
    ),

    // 🍽 مطاعم
    Landmark(
      id: '7',
      name: 'مطعم لوسين',
      position: LatLng(24.7000, 46.6700),
      imagePath: 'assets/images/lusin.jpeg',
      location: 'الرياض',
      rating: 4.8,
      category: '🍽 مطاعم',
      price: 150,
      description: 'مطعم أرمني فاخر بأجواء مميزة وأطباق رائعة.',
    ),

    // 🏫 جامعات
    Landmark(
      id: '8',
      name: 'جامعة الملك سعود',
      position: LatLng(24.7249, 46.6276),
      imagePath: 'assets/images/king_saud_university.jpeg',
      location: 'الرياض',
      rating: 4.9,
      category: '🏫 جامعات',
      price: 0,
      description: 'إحدى أعرق الجامعات في السعودية.',
    ),

    // 🏥 مستشفيات
    Landmark(
      id: '9',
      name: 'مستشفى الملك فيصل التخصصي',
      position: LatLng(24.6705, 46.6855),
      imagePath: 'assets/images/king_faisal_hospital.jpeg',
      location: 'الرياض',
      rating: 4.8,
      category: '🏥 مستشفيات',
      price: 0,
      description: 'مستشفى متقدم يقدم خدمات طبية متخصصة.',
    ),

    // 🏛 مباني حكومية
    Landmark(
      id: '10',
      name: 'قصر الحكم',
      position: LatLng(24.6328, 46.7134),
      imagePath: 'assets/images/qasr_al_hukm.jpeg',
      location: 'الرياض',
      rating: 4.7,
      category: '🏛 مباني حكومية',
      price: 0,
      description: 'مقر إمارة منطقة الرياض ومركز إداري تاريخي.',
    ),

    // ✈ مطارات
    Landmark(
      id: '11',
      name: 'مطار الملك خالد الدولي',
      position: LatLng(24.9578, 46.6980),
      imagePath: 'assets/images/king_khaled_airport.jpeg',
      location: 'الرياض',
      rating: 4.6,
      category: '✈ مطارات',
      price: 0,
      description: 'المطار الرئيسي في الرياض يربط المملكة بالعالم.',
    ),

    // أضف باقي المعالم هنا بنفس النمط
  ].obs;

  final filteredLandmarks = <Landmark>[].obs;
  final featuredLandmark = Landmark(
    id: 'featured_1',
    name: 'قصر المصمك',
    position: LatLng(24.6333, 46.7167),
    imagePath: 'assets/images/masmak.jpeg',
    location: 'الرياض',
    rating: 4.7,
    category: '🏙 معالم شهيرة',
    price: 50,
    description: 'قلعة تاريخية في قلب الرياض',
  ).obs;

  final MapController mapController = MapController();
  final users = <User>[].obs;
  final comments = <Comment>[].obs;

  @override
  void onInit() {
    super.onInit();

    _loadInitialData();
    ever(currentIndex, (index) {
      if (index == 0) {
        filteredLandmarks.assignAll(landmarks);
      }
    });
    filteredLandmarks.assignAll(landmarks);
    // تهيئة القائمة المصفاة
  }

  void _loadInitialData() {
    _loadUsers();
    _loadLandmarks();
    _loadComments();
  }

  void _loadUsers() {
    users.addAll([
      User(
        id: '1',
        name: 'محمد علي',
        avatarPath: 'assets/images/user1.jpg',
      ),
      User(
        id: '2',
        name: 'أحمد حسن',
        avatarPath: 'assets/images/user2.jpg',
      ),
    ]);
  }

  void _loadLandmarks() {
    final initialLandmarks = [
      Landmark(
        id: '1',
        name: 'المتحف الوطني',
        position: const LatLng(24.7136, 46.6753),
        imagePath: 'assets/images/Santorini.jpg',
        location: 'الرياض',
        rating: 4.8,
        category: 'التاريخية',
        price: 10,
        description: 'good',
      ),
      Landmark(
        id: '2',
        name: 'مركز المملكة',
        position: const LatLng(24.6475, 46.7144),
        imagePath: 'assets/images/welcome.jpg',
        location: 'الرياض',
        rating: 4.6,
        category: 'الأشهر',
        price: 10,
        description: 'good',
      ),
    ];

    landmarks.addAll(initialLandmarks);
    filteredLandmarks.assignAll(initialLandmarks);

    // تمت إضافة البيانات مسبقًا في القائمة المباشرة
  }

  void _loadComments() {
    comments.addAll([
      Comment(
        id: '1',
        userId: '1',
        landmarkId: '1',
        text: 'تجربة رائعة، أنصح الجميع بزيارته!',
        timestamp: DateTime.now().subtract(const Duration(days: 1)),
      ),
      Comment(
        id: '2',
        userId: '2',
        landmarkId: '2',
        text: 'مكان مميز للتعرف على التاريخ',
        timestamp: DateTime.now().subtract(const Duration(hours: 5)),
      )
    ]);
  }

  // الدالة الجديدة المطلوبة
  void filterByCategory(String category) {
    if (category == 'الكل') {
      filteredLandmarks.assignAll(landmarks);
    } else {
      filteredLandmarks.assignAll(
        landmarks.where((landmark) => landmark.category == category).toList(),
      );
    }
  }

  // الدالة القديمة مع تعديلات
  void filterLandmarks(String filterType) {
    switch (filterType) {
      case 'الأشهر':
        filteredLandmarks
            .assignAll(landmarks.where((l) => l.rating >= 4.5).toList());
        break;
      case 'القريبة':
        // إضافة منطق تحديد الموقع الحالي هنا
        break;
      case 'الجديدة':
        // إضافة منطق تحديد الجديد هنا
        break;
      case 'التاريخية':
        filteredLandmarks.assignAll(
            landmarks.where((l) => l.category.contains('تاريخ')).toList());
        break;
      default:
        filteredLandmarks.assignAll(landmarks);
    }
  }

  List<Comment> getCommentsForLandmark(String landmarkId) {
    return comments.where((c) => c.landmarkId == landmarkId).toList();
  }

  @override
  void onClose() {
    mapController.dispose();
    super.onClose();
  }
}

// import 'package:flutter/material.dart';
// import 'package:flutter_map/flutter_map.dart';
// import 'package:get/get.dart';
// import 'package:latlong2/latlong.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';

// class User {
//   final String id;
//   final String name;
//   final String avatarPath;

//   User({required this.id, required this.name, required this.avatarPath});

//   factory User.fromMap(Map<String, dynamic> data) {
//     return User(
//       id: data['id'],
//       name: data['name'],
//       avatarPath: data['avatarPath'],
//     );
//   }

//   Map<String, dynamic> toMap() {
//     return {
//       'id': id,
//       'name': name,
//       'avatarPath': avatarPath,
//     };
//   }
// }

// class Comment {
//   final String id;
//   final String userId;
//   final String landmarkId;
//   final String text;
//   final DateTime timestamp;

//   Comment({
//     required this.id,
//     required this.userId,
//     required this.landmarkId,
//     required this.text,
//     required this.timestamp,
//   });

//   factory Comment.fromMap(Map<String, dynamic> data) {
//     return Comment(
//       id: data['id'],
//       userId: data['userId'],
//       landmarkId: data['landmarkId'],
//       text: data['text'],
//       timestamp: (data['timestamp'] as Timestamp).toDate(),
//     );
//   }

//   Map<String, dynamic> toMap() {
//     return {
//       'id': id,
//       'userId': userId,
//       'landmarkId': landmarkId,
//       'text': text,
//       'timestamp': Timestamp.fromDate(timestamp),
//     };
//   }
// }

// class Landmark {
//   final String id;
//   final String name;
//   final LatLng position;
//   final String imagePath;
//   final String location;
//   final double rating;
//   final String category;
//   final double price;
//   final String description;

//   Landmark({
//     required this.id,
//     required this.name,
//     required this.position,
//     required this.imagePath,
//     required this.location,
//     required this.rating,
//     required this.category,
//     required this.price,
//     required this.description,
//   });

//   factory Landmark.fromMap(Map<String, dynamic> data) {
//     return Landmark(
//       id: data['id'],
//       name: data['name'],
//       position: LatLng(data['latitude'], data['longitude']),
//       imagePath: data['imagePath'],
//       location: data['location'],
//       rating: data['rating'].toDouble(),
//       category: data['category'],
//       price: data['price'].toDouble(),
//       description: data['description'],
//     );
//   }

//   Map<String, dynamic> toMap() {
//     return {
//       'id': id,
//       'name': name,
//       'latitude': position.latitude,
//       'longitude': position.longitude,
//       'imagePath': imagePath,
//       'location': location,
//       'rating': rating,
//       'category': category,
//       'price': price,
//       'description': description,
//     };
//   }
// }

// class LandmarkController extends GetxController {
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//   final RxInt currentIndex = 0.obs;
//   final categories = {
//     '🏙 معالم شهيرة': Icons.landscape,
//     '🎭 متاحف وأماكن ثقافية': Icons.museum,
//     '🌳 حدائق ومنتزهات': Icons.park,
//     '🐾 أماكن ترفيهية': Icons.attractions,
//     '🛍 تسوق': Icons.shopping_cart,
//     '🍽 مطاعم': Icons.restaurant,
//     '🏫 جامعات': Icons.school,
//     '🏥 مستشفيات': Icons.local_hospital,
//     '🏛 مباني حكومية': Icons.account_balance,
//     '✈ مطارات': Icons.flight,
//   };

//   final landmarks = <Landmark>[].obs;
//   final filteredLandmarks = <Landmark>[].obs;
//   final featuredLandmark = Landmark(
//     id: 'featured_1',
//     name: 'قصر المصمك',
//     position: LatLng(24.6333, 46.7167),
//     imagePath: 'assets/images/masmak.jpeg',
//     location: 'الرياض',
//     rating: 4.7,
//     category: '🏙 معالم شهيرة',
//     price: 50,
//     description: 'قلعة تاريخية في قلب الرياض',
//   ).obs;

//   final MapController mapController = MapController();
//   final users = <User>[].obs;
//   final comments = <Comment>[].obs;

//   @override
//   void onInit() {
//     super.onInit();
//     _initializeData();
//     ever(currentIndex, (index) {
//       if (index == 0) {
//         filteredLandmarks.assignAll(landmarks);
//       }
//     });
//   }

//   void _initializeData() async {
//     await fetchLandmarks();
//     await fetchUsers();
//     await fetchComments();
//   }

//   Future<void> fetchLandmarks() async {
//     try {
//       final snapshot = await _firestore.collection('landmarks').get();
//       landmarks.assignAll(
//         snapshot.docs.map((doc) => Landmark.fromMap(doc.data())).toList(),
//       );
//       filteredLandmarks.assignAll(landmarks);
//     } catch (e) {
//       Get.snackbar('خطأ', 'فشل في تحميل المعالم: ${e.toString()}');
//     }
//   }

//   Future<void> fetchUsers() async {
//     try {
//       final snapshot = await _firestore.collection('users').get();
//       users.assignAll(
//         snapshot.docs.map((doc) => User.fromMap(doc.data())).toList(),
//       );
//     } catch (e) {
//       Get.snackbar('خطأ', 'فشل في تحميل المستخدمين: ${e.toString()}');
//     }
//   }

//   Future<void> fetchComments() async {
//     try {
//       final snapshot = await _firestore.collection('comments').get();
//       comments.assignAll(
//         snapshot.docs.map((doc) => Comment.fromMap(doc.data())).toList(),
//       );
//     } catch (e) {
//       Get.snackbar('خطأ', 'فشل في تحميل التعليقات: ${e.toString()}');
//     }
//   }

//   Future<void> addLandmark(Landmark landmark) async {
//     try {
//       await _firestore.collection('landmarks').doc(landmark.id).set(landmark.toMap());
//       landmarks.add(landmark);
//       Get.snackbar('نجاح', 'تمت إضافة المعلم بنجاح');
//     } catch (e) {
//       Get.snackbar('خطأ', 'فشل في إضافة المعلم: ${e.toString()}');
//     }
//   }

//   Future<void> addUser(User user) async {
//     try {
//       await _firestore.collection('users').doc(user.id).set(user.toMap());
//       users.add(user);
//       Get.snackbar('نجاح', 'تمت إضافة المستخدم بنجاح');
//     } catch (e) {
//       Get.snackbar('خطأ', 'فشل في إضافة المستخدم: ${e.toString()}');
//     }
//   }

//   Future<void> addComment(Comment comment) async {
//     try {
//       await _firestore.collection('comments').doc(comment.id).set(comment.toMap());
//       comments.add(comment);
//       Get.snackbar('نجاح', 'تمت إضافة التعليق بنجاح');
//     } catch (e) {
//       Get.snackbar('خطأ', 'فشل في إضافة التعليق: ${e.toString()}');
//     }
//   }

//   void filterByCategory(String category) {
//     if (category == 'الكل') {
//       filteredLandmarks.assignAll(landmarks);
//     } else {
//       filteredLandmarks.assignAll(
//         landmarks.where((landmark) => landmark.category == category).toList(),
//       );
//     }
//   }

//   void filterLandmarks(String filterType) {
//     switch (filterType) {
//       case 'الأشهر':
//         filteredLandmarks.assignAll(landmarks.where((l) => l.rating >= 4.5).toList());
//         break;
//       case 'القريبة':
//         // سيتم إضافة منطق الموقع لاحقًا
//         break;
//       case 'الجديدة':
//         // سيتم إضافة منطق التاريخ لاحقًا
//         break;
//       case 'التاريخية':
//         filteredLandmarks.assignAll(
//             landmarks.where((l) => l.category.contains('تاريخ')).toList());
//         break;
//       default:
//         filteredLandmarks.assignAll(landmarks);
//     }
//   }

//   List<Comment> getCommentsForLandmark(String landmarkId) {
//     return comments.where((c) => c.landmarkId == landmarkId).toList();
//   }

//   @override
//   void onClose() {
//     mapController.dispose();
//     super.onClose();
//   }
// }